/** Automatically generated file. DO NOT MODIFY */
package com.example.customlists_36;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}