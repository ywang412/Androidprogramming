package com.caveofprogramming.android.notesquirrel;

import java.util.List;

import android.graphics.Point;

public interface PointCollecterListener {
	public void pointsCollected(List<Point> points);
}
